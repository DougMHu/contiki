#!/bin/bash
# My first script
cd ~/contiki/examples/rime/
sudo python prep_tmote.py
sudo make login
